from django.urls import path
from . import views
from users.views import update_user , delete_user 

urlpatterns = [
    path('<int:user_id>/', views.user_reservation_page, name='user_reservation'),  
    path('<int:user_id>/user_info/', update_user, name='user_info'), 
    path('user/delete/<int:user_id>/', delete_user, name='delete_user'), 
    path('create/', views.create_reservation, name='create_reservation'),
    path('my-reservations/', views.my_reservations_view, name='my_reservations'),
]
